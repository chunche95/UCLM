package DataManager;

public class Excepciones extends Exception {
    public Excepciones(String m) {
        super(m);
    }
}
