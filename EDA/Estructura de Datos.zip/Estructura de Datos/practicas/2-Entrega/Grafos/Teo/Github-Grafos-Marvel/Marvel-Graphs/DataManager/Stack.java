package DataManager;

public class Stack {
}
