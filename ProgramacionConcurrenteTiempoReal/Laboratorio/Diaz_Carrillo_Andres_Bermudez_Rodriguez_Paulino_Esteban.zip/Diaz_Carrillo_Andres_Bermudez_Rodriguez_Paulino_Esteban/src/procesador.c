#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#define MAX_BUFFER 500

/**
 * Abre un archivo, lo lee en un búfer y luego busca en el búfer una cadena dada
 * 
 * @param nombreFichero El nombre del archivo a leer.
 * @param patron la cadena a buscar
 */
void comprobarParecidos(char* nombreFichero, char* patron) {
    FILE* fichero;
    int numeroLineas = 1;
    char buffer[MAX_BUFFER];
    char texto[MAX_BUFFER];
    /* Comprobando si el archivo está abierto. */
    if ((fichero = fopen(nombreFichero, "r")) == NULL) {
        printf(" Error: Falloal abrir el archivo. \n");
    } else {
        /* Leyendo el archivo línea por línea y concatenando las líneas en una sola cadena. */
        while (fgets(buffer, MAX_BUFFER, fichero)) {
            strcat(texto, buffer);
        }
        fclose(fichero);

        const char* pPatron = patron;
        char caracter = pPatron[0];
        int sizePatron = strlen(pPatron);
        int sizeText = strlen(texto);
        int i = 0;

        /* Contando el número de líneas en el archivo. */
        while (i < sizeText) {
            if (texto[i] == '\n')
            {
                ++numeroLineas;
            }
           /* Comprobando si el carácter en el texto es el mismo que el carácter en el patrón. Si es
           así, comprueba si el patrón está en el texto. Si es así, imprime el número de línea y el
           patrón. */
            if (texto[i] == caracter) {
                /* Comparando el texto[i] con el pPatron y si son iguales imprime el número de línea y
                el pPatron. */
                if (strncmp(&texto[i], pPatron, sizePatron) == 0) {
                    printf(" Procesador: %d Patron '%s' en la linea ",getpid(), pPatron);
                    printf("%d\n",numeroLineas);
                }
            }
            i++;
        }
    }
}

/**
 * Compara dos cadenas y devuelve el número de caracteres que son iguales en la misma posición
 * 
 * @param argc El número de argumentos pasados al programa.
 * @param argv matriz de cadenas
 * 
 * @return el número de veces que se repite la palabra en el archivo.
 */
int main(int argc, char* argv[]) {
    comprobarParecidos(argv[1], argv[2]);
    return EXIT_SUCCESS;
}
