//
// Created by pauli on 09/04/2023.
//

#ifndef PCTR_ENTREGAS_FILOSOFO_H
#define PCTR_ENTREGAS_FILOSOFO_H


class filosofo {

};


#endif //PCTR_ENTREGAS_FILOSOFO_H
