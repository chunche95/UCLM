//
// Created by pauli on 09/04/2023.
//

#ifndef PCTR_ENTREGAS_MANAGER_H
#define PCTR_ENTREGAS_MANAGER_H


class manager {

};


#endif //PCTR_ENTREGAS_MANAGER_H
